import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { useState, useEffect } from 'react';
import * as Notifications from 'expo-notifications';
import Welcome from './components/Welcome';
import Login from './components/Login';
import Home from './components/Home';
import Products from './components/Products';
import Carrinho from './components/Carrinho';
import Profile from './components/Profile';
import Orders from './components/Orders';
import Checkout from './components/Checkout';
import Settings from './components/Settings';
import Restaurant from './components/Restaurant';
import RestaurantDetail from "./components/RestaurantDetails";
import Ionicons from '@expo/vector-icons/Ionicons';

const Stack = createStackNavigator();
const Tab = createBottomTabNavigator();

export default function App() {
  const [carrinho, setCarrinho] = useState([]);
  const [email, setEmail] = useState('');

  useEffect(() => {
    const configureNotifications = async () => {
      const { status } = await Notifications.requestPermissionsAsync();
      if (status !== 'granted') {
        console.warn('Permissões de notificação não concedidas.');
        return;
      }

      if (Platform.OS === 'android') {
        await Notifications.setNotificationChannelAsync('default', {
          name: 'Default',
          importance: Notifications.AndroidImportance.HIGH,
        });
      }

      Notifications.setNotificationHandler({
        handleNotification: async () => ({
          shouldShowAlert: true,
          shouldPlaySound: true,
          shouldSetBadge: false,
        }),
      });
    };

    configureNotifications();
  }, []);

  const adicionarAoCarrinho = (produto) => {
    setCarrinho((prevCarrinho) => {
      const existente = prevCarrinho.find((item) => item.id === produto.id);
      if (existente) {
        return prevCarrinho.map((item) =>
          item.id === produto.id
            ? { ...item, quantidade: item.quantidade + 1 }
            : item
        );
      }
      return [...prevCarrinho, { ...produto, quantidade: 1 }];
    });
  };

  const calcularTotal = () =>
    carrinho.reduce((total, item) => total + item.preco * item.quantidade, 0);

  const removerItem = (id) => {
    setCarrinho((prevCarrinho) => prevCarrinho.filter((item) => item.id !== id));
  };

  const Tabs = () => (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        tabBarIcon: ({ color, size }) => {
          let iconName;
          if (route.name === 'Home') iconName = 'home';
          else if (route.name === 'Profile') iconName = 'person';
          else if (route.name === 'Settings') iconName = 'settings';
          return <Ionicons name={iconName} size={size} color={color} />;
        },
        tabBarActiveTintColor: '#FF011B',
        tabBarInactiveTintColor: 'gray',
        headerShown: false,
      })}
    >
      <Tab.Screen name="Home" component={HomeWithProps} />
      <Tab.Screen
        name="Carrinho"
        component={CarrinhoWithProps}
        options={{
          tabBarButton: () => null,
        }}
      />
      <Tab.Screen name="Profile" component={ProfileWithProps} />
      <Tab.Screen
        name="Orders"
        component={Orders}
        options={{
          tabBarButton: () => null,
        }}
      />
      <Tab.Screen name="Settings" component={Settings} />
    </Tab.Navigator>
  );

  const HomeWithProps = (props) => (
    <Home {...props} adicionarAoCarrinho={adicionarAoCarrinho} />
  );

  const CarrinhoWithProps = (props) => (
    <Carrinho
      {...props}
      carrinho={carrinho}
      calcularTotal={calcularTotal}
      removerItem={removerItem}
    />
  );

  const ProfileWithProps = (props) => (
    <Profile {...props} email={email} />
  );

  return (
    <NavigationContainer>
<Stack.Navigator initialRouteName="Welcome">
  <Stack.Screen
    name="Welcome"
    component={Welcome}
    options={{ headerShown: false }}
  />
  <Stack.Screen name="Login">
    {(props) => (
      <Login
        {...props}
        onLoginSuccess={(userEmail) => {
          setEmail(userEmail);
          props.navigation.navigate('Home');
        }}
      />
    )}
  </Stack.Screen>
  <Stack.Screen name="Home" component={Tabs} options={{ headerShown: false }} />
  <Stack.Screen
    name="Products"
    children={(props) => (
      <Products {...props} adicionarAoCarrinho={adicionarAoCarrinho} />
    )}
  />
  <Stack.Screen name="Checkout" component={Checkout} />
  <Stack.Screen name="Orders" component={Orders} />
  <Stack.Screen
    name="Restaurant"
    component={Restaurant}
    options={{ title: 'Restaurantes Parceiros' }}  
  />
  <Stack.Screen
    name="RestaurantDetail"
    component={RestaurantDetail}
    options={{ title: 'Detalhes' }}  
  />
</Stack.Navigator>
    </NavigationContainer>
  );
}
