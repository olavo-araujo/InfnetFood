# InfnetFood

O **InfnetFood** é um aplicativo desenvolvido para pedidos e delivery de refeições, implementado em React Native com Expo. Este projeto foi estruturado em etapas e abrangeu várias funcionalidades para garantir uma experiência completa e fluida aos usuários.

## Instruções para Execução

### Requisitos
- Node.js
- Expo CLI
- Git

### Instalação

1. Clone este repositório:

```bash
git clone https://github.com/olavo.araujo/InfnetFood.git
```

2. Navegue até o diretório do projeto:
```bash
cd InfnetFood
```

3. Instale as dependências do projeto:
```bash
npm install
```

4. Execute o projeto com Expo:
```bash
expo start
```

### Funcionalidades Implementadas
- Tela de Login
A tela de login permite ao usuário acessar o app utilizando dados mockados. Campos de e-mail e senha são validados, com mensagens de erro para entradas inválidas.

- Página Inicial e Listagem de Categorias
A tela inicial exibe categorias de refeições (Lanches, Bebidas, Sobremesas) utilizando FlatList para listá-las de forma scrollável.

- Tela de Produtos
Após selecionar uma categoria, o usuário é redirecionado para a tela que exibe os produtos daquela categoria.

- Carrinho de Compras
Implementação de um carrinho básico que mostra os itens selecionados, suas quantidades e o preço total. O estado do carrinho é gerenciado localmente.

- Tela de Perfil
A tela de perfil exibe informações do usuário logado, como nome e e-mail, com dados mockados.

- Tela de Pedidos
Exibição dos pedidos em curso do usuário, utilizando FlatList para listar os itens.

- Mapa Simulado
Um mapa com 10 restaurantes no Centro do Rio de Janeiro é exibido, utilizando uma imagem simulada e dados mockados para os restaurantes.

- Tela de Detalhes do Restaurante
Exibe informações detalhadas de um restaurante selecionado, como nome, endereço e um item do cardápio.

- Tela de Checkout
Tela de checkout onde o usuário pode revisar seu pedido e fornecer dados de entrega e pagamento, com validação simples.

- Feedbacks Visuais
Interações visuais básicas foram adicionadas, como animações e mudanças de cores ao adicionar itens ao carrinho ou confirmar um pedido.

# Conclusão
O InfnetFood oferece uma solução completa para pedidos e delivery de refeições, com foco na simplicidade e eficiência. Embora tenha enfrentado alguns desafios ao longo do caminho, o projeto foi finalizado com sucesso e segue em constante aprimoramento.