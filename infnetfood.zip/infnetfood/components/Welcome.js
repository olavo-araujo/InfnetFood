import { View, Text, Image, StyleSheet, TouchableOpacity } from 'react-native';

export default function Welcome({ navigation }) {
  return (
    <View style={styles.container}>
      <Image source={require('../assets/logo.png')} style={styles.logo} />
      <Text style={styles.titulo}>Bem-vindo!</Text>
      <TouchableOpacity
        style={styles.botao}
        onPress={() => navigation.navigate('Login')}>
        <Text style={styles.textoBotao}>Entrar</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FF011B',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20,
  },
  logo: {
    width: 200,
    height: 200,
    tintColor: '#FFFFFF',
    resizeMode: 'contain',
  },
  titulo: {
    fontSize: 24,
    color: '#FFFFFF',
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 20,
  },
  botao: {
    backgroundColor: '#FFFFFF',
    paddingVertical: 10,
    paddingHorizontal: 40,
    borderRadius: 8,
  },
  textoBotao: {
    color: '#FF011B',
    fontSize: 18,
    fontWeight: 'bold',
  },
});

