import { View, Text, TouchableOpacity, StyleSheet, ScrollView } from 'react-native';
import Ionicons from '@expo/vector-icons/Ionicons';

export default function Carrinho({ carrinho, calcularTotal, navigation, removerItem }) {

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity
          style={styles.headerButton}
          onPress={() => navigation.navigate('Orders')}>
          <Ionicons name="time" size={24} color="#fff" />
        </TouchableOpacity>
        <TouchableOpacity
          style={styles.headerButton}
          onPress={() => navigation.navigate('Carrinho')}>
          <Ionicons name="cart" size={24} color="#fff" />
        </TouchableOpacity>
      </View>
      <Text style={styles.title}>Carrinho de Compras</Text>
      {carrinho.length === 0 ? (
        <Text style={styles.emptyText}>Seu carrinho está vazio</Text>
      ) : (
        <View style={styles.itemsList}>
          {carrinho.map((item) => (
            <View key={item.id} style={styles.item}>
              <Text style={styles.itemName}>{item.nome}</Text>
              <Text style={styles.itemQuantidade}>Qtd: {item.quantidade}</Text>
              <Text style={styles.itemPreco}>R${item.preco * item.quantidade}</Text>
              
              <TouchableOpacity
                style={styles.removeButton}
                onPress={() => removerItem(item.id)}>
                <Ionicons name="close-circle" size={24} color="#fff" />
              </TouchableOpacity>
            </View>
          ))}
        </View>
      )}
      <View style={styles.totalContainer}>
        <Text style={styles.totalText}>Total: R${calcularTotal()}</Text>
        <TouchableOpacity
          style={styles.checkoutButton}
          onPress={() => navigation.navigate('Checkout', { carrinho, total: calcularTotal() })}>
          <Text style={styles.checkoutButtonText}>Finalizar Compra</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    paddingHorizontal: 16,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: 40,
    marginBottom: 16,
  },
  headerButton: {
    backgroundColor: '#FF011B',
    paddingVertical: 8,
    paddingHorizontal: 8,
    borderRadius: 8,
  },
  title: {
    fontSize: 22,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 16,
  },
  emptyText: {
    textAlign: 'center',
    fontSize: 18,
    color: '#FF011B',
  },
  itemsList: {
    marginBottom: 20,
  },
  item: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    padding: 16,
    backgroundColor: '#FF011B',
    borderRadius: 8,
    marginBottom: 10,
    position: 'relative',
  },
  itemName: {
    fontSize: 18,
    color: '#fff',
  },
  itemQuantidade: {
    fontSize: 16,
    color: '#fff',
  },
  itemPreco: {
    fontSize: 16,
    color: '#fff',
  },
  removeButton: {
    position: 'absolute',
    top: -8, 
    left: -8, 
    zIndex: 1, 
  },
  totalContainer: {
    backgroundColor: '#F5F5F5',
    padding: 20,
    borderRadius: 10,
    marginTop: 30,
  },
  totalText: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 20,
  },
  checkoutButton: {
    backgroundColor: '#FF011B',
    paddingVertical: 12,
    borderRadius: 8,
    alignItems: 'center',
  },
  checkoutButtonText: {
    fontSize: 18,
    color: '#fff',
    fontWeight: 'bold',
  },
});
