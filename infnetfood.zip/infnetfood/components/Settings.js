import { View, Text, Switch, StyleSheet } from 'react-native';

export default function Settings({ temaEscuro, setTemaEscuro, notificacoesAtivas, setNotificacoesAtivas }) {
  return (
    <View style={[styles.container, temaEscuro && styles.containerEscuro]}>
      <Text style={[styles.title, temaEscuro && styles.titleEscuro]}>Configurações</Text>

      <View style={[styles.settingItem, styles.firstItem]}>
        <Text style={[styles.label, temaEscuro && styles.labelEscuro]}>Modo Escuro</Text>
        <Switch
          value={temaEscuro}
          onValueChange={setTemaEscuro}
          trackColor={{ false: '#CCC', true: '#FF011B' }}
          thumbColor={temaEscuro ? '#FFF' : '#FF011B'}
        />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    padding: 20,
  },
  containerEscuro: {
    backgroundColor: '#1C1C1C',
  },
  title: {
    fontSize: 26,
    fontWeight: 'bold',
    color: '#FF011B',
    marginBottom: 20,
    marginTop: 40, 
  },
  titleEscuro: {
    color: '#FF011B',
  },
  settingItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 10,
    paddingHorizontal: 16,
    backgroundColor: '#F5F5F5',
    borderRadius: 8,
    marginBottom: 20,
  },
  firstItem: {
    marginTop: 20, 
  },
  label: {
    fontSize: 18,
    color: '#333',
    fontWeight: '600',
  },
  labelEscuro: {
    color: '#FFF',
  },
});
