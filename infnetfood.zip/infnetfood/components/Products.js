import { View, Text, FlatList, Image, TouchableOpacity, StyleSheet, ScrollView } from 'react-native';

const produtosPorCategoria = {
  Lanches: [
    { id: 1, nome: 'Hambúrguer', preco: 15.0 },
    { id: 2, nome: 'Batata Frita', preco: 10.0 },
  ],
  Bebidas: [
    { id: 3, nome: 'Refrigerante', preco: 5.0 },
    { id: 4, nome: 'Cerveja Artesanal', preco: 12.0 },
  ],
  Sobremesas: [
    { id: 5, nome: 'Sorvete de Chocolate', preco: 8.0 },
    { id: 6, nome: 'Picolé de Frutas', preco: 4.0 },
  ],
};

const detalhesRestaurante = {
  Lanches: {
    nome: 'Para Lanches',
    endereco: 'Rua dos Lanches, 123',
    logo: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRgKQyCrwYJGnLY1iphF0MIM88Scrg0hpFvIw&s',
  },
  Bebidas: {
    nome: 'Adega Mansão Maromba',
    endereco: 'Av. das Bebidas, 456',
    logo: 'https://seeklogo.com/images/M/mansao-maromba-logo-26D97621A9-seeklogo.com.png',
  },
  Sobremesas: {
    nome: 'Oggi Sorvetes',
    endereco: 'Praça dos Doces, 789',
    logo: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQz-mk-S7Kt6zU3wYcQ1IrEwNaeA55GSQS3gA&s',
  },
};

export default function Products({ route, adicionarAoCarrinho }) {
  const { categoria } = route.params;
  const produtos = produtosPorCategoria[categoria] || [];
  const detalhes = detalhesRestaurante[categoria] || {};

  return (
    <ScrollView style={styles.container}>
      <View style={styles.detalhesContainer}>
        <Image source={{ uri: detalhes.logo }} style={styles.logo} />
        <View style={styles.detalhesTexto}>
          <Text style={styles.nomeRestaurante}>{detalhes.nome}</Text>
          <Text style={styles.endereco}>{detalhes.endereco}</Text>
        </View>
      </View>
      <FlatList
        data={produtos}
        keyExtractor={(item) => item.id.toString()}
        renderItem={({ item }) => (
          <View style={styles.produto}>
            <Text style={styles.nome}>{item.nome}</Text>
            <Text style={styles.preco}>R$ {item.preco.toFixed(2)}</Text>
            <TouchableOpacity
              style={styles.botao}
              onPress={() => adicionarAoCarrinho(item)}>
              <Text style={styles.textoBotao}>Adicionar</Text>
            </TouchableOpacity>
          </View>
        )}
        contentContainerStyle={styles.listaProdutos}
      />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#fff' },
  detalhesContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#f9f9f9',
    padding: 16,
    margin: 10,
    borderRadius: 8,
  },
  logo: {
    width: 60,
    height: 60,
    borderRadius: 30,
    marginRight: 16,
    backgroundColor: '#fff',
  },
  detalhesTexto: { flex: 1 },
  nomeRestaurante: { fontSize: 18, fontWeight: 'bold', color: '#333' },
  endereco: { fontSize: 14, color: '#666', marginTop: 4 },
  listaProdutos: { padding: 10 },
  produto: {
    padding: 16,
    marginBottom: 12,
    backgroundColor: '#f9f9f9',
    borderRadius: 8,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  nome: { fontSize: 16, fontWeight: 'bold', color: '#333' },
  preco: { fontSize: 14, color: '#555' },
  botao: {
    backgroundColor: '#FF011B',
    padding: 10,
    borderRadius: 5,
  },
  textoBotao: { color: 'white', fontWeight: 'bold' },
});
