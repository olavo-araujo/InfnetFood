import { View, Text, StyleSheet, FlatList, TouchableOpacity, Image } from 'react-native';
import { useNavigation } from '@react-navigation/native';

const RESTAURANTS = [
  {
    id: '1',
    name: 'Bar da Lapa',
    address: 'Avenida Mem de Sá, 69 - Centro, RJ',
    image: 'https://www.rioigo.com/wp-content/uploads/2016/04/enchendo-linguica.jpg',
    menuExample: { name: 'Picanha na Chapa', price: '129.90' },
  },
  {
    id: '2',
    name: 'Cais do Oriente',
    address: 'R. Visc. de Itaboraí, 8 - Centro, RJ',
    image: 'https://lh3.googleusercontent.com/p/AF1QipOfjDLsYLqrB7yD5e5zW_WWuB4AOTluYWglUpDA=s680-w680-h510',
    menuExample: { name: 'Camarão Crocante com Risoto', price: '89.90' },
  },
  {
    id: '3',
    name: 'Ladeira 7',
    address: 'Ladeira do João Homem, 7 - Centro, RJ',
    image: 'https://lh3.googleusercontent.com/p/AF1QipNStER24oVccSFwrVPtMpUnfy3Nb99Y2OooEcWS=s680-w680-h510',
    menuExample: { name: 'Feijoada', price: '99.90' },
  },
  {
    id: '4',
    name: 'Porto Carioca',
    address: 'R. do Rosário, 36 - Centro, RJ',
    image: 'https://lh5.googleusercontent.com/p/AF1QipPtgLiQpGl8b1RnuhopYlIT2_XRXJV7zfWgbCKG=w260-h175-n-k-no',
    menuExample: { name: 'Bacalhau à Brás', price: '109.90' },
  },
  {
    id: '5',
    name: 'Bar do Peixe',
    address: 'R. André Cavalcanti, 16b - Centro, RJ',
    image: 'https://lh5.googleusercontent.com/p/AF1QipP5cEirRI3ZZPycNx6lo9zqfgNe33UtprNTBGee=w260-h175-n-k-no',
    menuExample: { name: 'Churrasco Gaúcho', price: '119.90' },
  },
  {
    id: '6',
    name: 'Xian Rio',
    address: 'Av. Alm. Silvio de Noronha, 365 - Centro, RJ',
    image: 'https://lh3.googleusercontent.com/p/AF1QipOglfGg0Zw3RlWjcGabxngJgCwEtMPk6U19t5Vv=s680-w680-h510',
    menuExample: { name: 'Barca de Sashimi', price: '133.90' },
  },
  {
    id: '7',
    name: 'Coliseu das Massas',
    address: 'R. Sete de Setembro, 171 - Centro, RJ',
    image: 'https://lh3.googleusercontent.com/p/AF1QipPKUHxpSnWbYC4qPCBCpoBqS_McP5g_oRfeWkVE=s680-w680-h510',
    menuExample: { name: 'Pizza Portuguesa Gigante', price: '69.90' },
  },
  {
    id: '8',
    name: 'Santo Scenarium',
    address: 'R. do Lavradio, 36 - Centro, RJ',
    image: 'https://lh3.googleusercontent.com/p/AF1QipPCc1CWQPX54HMplVfH-o1ECbLXgkB4WdYhKMAf=s680-w680-h510',
    menuExample: { name: 'Lasagna à Bolonhesa', price: '79.90' },
  },
  {
    id: '9',
    name: 'Lilia',
    address: 'R. do Senado, 45 - Centro, RJ',
    image: 'https://lh5.googleusercontent.com/p/AF1QipMVRzugMzJ6iUY-N3WltidMqnu6vS6S7m8-1VqH=w260-h175-n-k-no',
    menuExample: { name: 'Frango Defumado', price: '119.90' },
  },
  {
    id: '10',
    name: 'Adega Flor de Coimbra',
    address: 'R. Teotônio Regadas, 34 - Centro, RJ',
    image: 'https://lh5.googleusercontent.com/p/AF1QipMMxeIfuKNZpdxwRhAa-D51MFLnlQgEhRQgl2Bp=w260-h175-n-k-no',
    menuExample: { name: 'Bacalhau Grelhado', price: '139.90' },
  },
];

export default function Restaurant() {
  const navigation = useNavigation();

  const renderRestaurantItem = ({ item }) => (
    <TouchableOpacity
      style={styles.restaurantItem}
      onPress={() =>
        navigation.navigate('RestaurantDetail', { restaurant: item })
      }
    >
      <Image source={{ uri: item.image }} style={styles.restaurantImage} />
      <View style={styles.textContainer}>
        <Text style={styles.restaurantName}>{item.name}</Text>
        <Text style={styles.restaurantAddress}>{item.address}</Text>
        <Text style={styles.menuExample}>
          {item.menuExample.name} - R$ {item.menuExample.price}
        </Text>
      </View>
    </TouchableOpacity>
  );

  return (
    <View style={styles.container}>
      <Image
        source={require('../assets/mapWeb.png')}
        style={styles.cityImage}
      />
      <Text style={styles.title}>Restaurantes</Text>
      <FlatList
        data={RESTAURANTS}
        keyExtractor={(item) => item.id}
        renderItem={renderRestaurantItem}
        contentContainerStyle={styles.listContainer}
        showsVerticalScrollIndicator={false}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingHorizontal: 16,
    backgroundColor: '#fff',
  },
  cityImage: {
    width: '100%',
    height: 200,
    borderRadius: 10,
    marginBottom: 20,
    marginTop: 20, 
  },
  title: {
    fontSize: 26,
    fontWeight: 'bold',
    textAlign: 'center',
    color: '#FF011B',
    marginBottom: 15,
  },
  listContainer: {
    paddingBottom: 20,
  },
  restaurantItem: {
    padding: 15,
    marginVertical: 10,
    borderRadius: 12,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FF011B',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.2,
    shadowRadius: 6,
    elevation: 6,
  },
  restaurantImage: {
    width: 90,
    height: 90,
    borderRadius: 10,
    marginRight: 15,
  },
  textContainer: {
    flex: 1,
    justifyContent: 'center',
  },
  restaurantName: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 5,
    color: '#fff',
  },
  restaurantAddress: {
    fontSize: 14,
    color: '#fff',
    marginBottom: 10,
  },
  menuExample: {
    fontSize: 14,
    fontStyle: 'italic',
    color: '#fff',
  },
});
