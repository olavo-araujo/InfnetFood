import { useEffect } from 'react';
import { View, Text, TouchableOpacity, Image, StyleSheet, ScrollView } from 'react-native';
import * as Notifications from 'expo-notifications';
import Ionicons from '@expo/vector-icons/Ionicons';

const restaurantes = [
  {
    id: 1,
    nome: 'Para Lanches',
    logo: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRgKQyCrwYJGnLY1iphF0MIM88Scrg0hpFvIw&s',
    categoria: 'Lanches',
  },
  {
    id: 2,
    nome: 'Adega Mansão Maromba',
    logo: 'https://seeklogo.com/images/M/mansao-maromba-logo-26D97621A9-seeklogo.com.png',
    categoria: 'Bebidas',
  },
  {
    id: 3,
    nome: 'Oggi Sorvetes',
    logo: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQz-mk-S7Kt6zU3wYcQ1IrEwNaeA55GSQS3gA&s',
    categoria: 'Sobremesas',
  },
];

export default function Home({ navigation }) {
  useEffect(() => {
    const showNotification = async () => {
      await Notifications.scheduleNotificationAsync({
        content: {
          title: 'Promoção em Para Lanches!',
          body: 'Confira as ofertas especiais agora mesmo!',
        },
        trigger: null,
      });
    };

    showNotification();
  }, []);

  const handleRestaurantePress = (restaurante) => {
    navigation.navigate('Products', { categoria: restaurante.categoria });
  };

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity
          style={styles.headerButton}
          onPress={() => navigation.navigate('Orders')}
        >
          <Ionicons name="time" size={24} color="#fff" />
        </TouchableOpacity>
        <TouchableOpacity
          style={styles.headerButton}
          onPress={() => navigation.navigate('Carrinho')}
        >
          <Ionicons name="cart" size={24} color="#fff" />
        </TouchableOpacity>
      </View>
      <Text style={styles.title}>Restaurantes</Text>
      <View style={styles.lista}>
        {restaurantes.map((item) => (
          <TouchableOpacity
            key={item.id}
            style={styles.restaurante}
            onPress={() => handleRestaurantePress(item)}
          >
            <Image source={{ uri: item.logo }} style={styles.logo} />
            <Text style={styles.nome}>{item.nome}</Text>
          </TouchableOpacity>
        ))}
      </View>
      <View style={styles.contentRestaurant}>
        <Text style={styles.welcomeTextRestaurant}>Restaurantes Parceiros</Text>
        <Image
          source={require('../assets/mapWeb.png')}
          style={styles.image4}
        />
        <Text style={styles.restaurantText}>
          Explore os melhores restaurantes parceiros no coração da cidade.
          Descubra sabores únicos, pratos deliciosos e experiências
          gastronômicas que vão transformar sua próxima refeição. Nossos
          parceiros oferecem uma variedade de opções para agradar a todos os
          gostos, desde os clássicos da culinária brasileira até as mais
          modernas criações internacionais.
        </Text>

        <TouchableOpacity
  style={styles.button}
  onPress={() => navigation.navigate('Restaurant')}
>
  <Text style={styles.buttonText}>Ver Mais</Text>
</TouchableOpacity>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { 
    flex: 1, 
    backgroundColor: '#fff', 
    paddingHorizontal: 16,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: 40, 
    marginBottom: 16,
  },
  headerButton: {
    backgroundColor: '#FF011B',
    paddingVertical: 8,
    paddingHorizontal: 8,
    borderRadius: 8,
    flexDirection: 'row',
    alignItems: 'center',
  },
button: {
  backgroundColor: '#FF011B',
  padding: 12,
  borderRadius: 8,
  alignItems: 'center',
  marginTop: 20,
},
buttonText: {
  color: '#fff',
  fontSize: 16,
  fontWeight: 'bold',
},
  title: { fontSize: 22, fontWeight: 'bold', textAlign: 'center', marginBottom: 16 },
  lista: { marginBottom: 20 },
  restaurante: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 20,
    marginBottom: 10,
    backgroundColor: '#FF011B',
    borderRadius: 8,
  },
  logo: {
    width: 50,
    height: 50,
    borderRadius: 25,
    marginRight: 16,
    backgroundColor: '#fff',
  },
  nome: { fontSize: 18, color: '#fff', fontWeight: 'bold' },
  contentRestaurant: {
    backgroundColor: '#F5F5F5',
    padding: 20,
    borderRadius: 10,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#E0E0E0',
    marginBottom: 30,
  },
  welcomeTextRestaurant: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#C90c0c',
    marginBottom: 20,
    textAlign: 'center',
    textDecorationLine: 'underline',
  },
  restaurantText: {
    fontSize: 16,
    color: '#333',
    marginTop: 10,
    textAlign: 'justify',
  },
  image4: {
    width: '90%',
    height: 200,
    borderRadius: 10,
    marginBottom: 15,
    borderWidth: 1,
    borderColor: '#E0E0E0',
  },
});
