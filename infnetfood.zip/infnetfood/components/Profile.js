import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Image } from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import * as ImagePicker from 'expo-image-picker';

export default function Profile({ email }) {
  const [nome, setNome] = useState('');
  const [imagem, setImagem] = useState('https://via.placeholder.com/150');

  const handleImagePicker = async () => {
    const permissionResult = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (permissionResult.granted) {
      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        allowsEditing: true,
        aspect: [1, 1],
        quality: 1,
      });
      if (!result.canceled) {
        setImagem(result.assets[0].uri);
      }
    }
  };

  const handleSave = () => {
    alert('Informações salvas!');
  };

  return (
    <View style={styles.container}>
      <Text style={styles.titulo}>Perfil</Text>
      <TouchableOpacity onPress={handleImagePicker} style={styles.avatarContainer}>
        <Image source={{ uri: imagem }} style={styles.avatar} />
        <MaterialIcons name="edit" size={24} color="white" style={styles.editIcon} />
      </TouchableOpacity>
      <View style={styles.formContainer}>
        <Text style={styles.label}>Nome:</Text>
        <TextInput
          style={styles.input}
          value={nome}
          onChangeText={setNome}
          placeholder="Digite seu nome"
        />
        <Text style={styles.label}>E-mail:</Text>
        <TextInput
          style={styles.input}
          value={email}
          editable={false}
        />
        <TouchableOpacity onPress={handleSave} style={styles.saveButton}>
          <Text style={styles.saveButtonText}>Salvar</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 16, backgroundColor: '#fff' },
  titulo: { fontSize: 24, fontWeight: 'bold', marginBottom: 20, textAlign: 'center' },
  avatarContainer: { alignItems: 'center', marginBottom: 20 },
  avatar: { width: 120, height: 120, borderRadius: 60, borderWidth: 4, borderColor: '#FF011B' },
  editIcon: { position: 'absolute', bottom: 0, right: 0, backgroundColor: '#FF011B', padding: 5, borderRadius: 50 },
  formContainer: { width: '100%' },
  label: { fontSize: 16, marginBottom: 5 },
  input: {
    width: '100%',
    padding: 10,
    fontSize: 16,
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 5,
    marginBottom: 20,
  },
  saveButton: {
    backgroundColor: '#FF011B',
    padding: 15,
    borderRadius: 8,
    alignItems: 'center',
  },
  saveButtonText: { color: '#fff', fontSize: 18 },
});
