import { useEffect, useState } from 'react';
import { View, Text, FlatList, StyleSheet } from 'react-native';

export default function Orders({ route }) {
  const [pedidos, setPedidos] = useState([]);

  useEffect(() => {
    if (route.params?.pedidos) {
      setPedidos(route.params.pedidos);
    }
  }, [route.params]);

  const gerarEstimativa = () => {
    const minutos = Math.floor(Math.random() * 30) + 10;
    return `${minutos} minutos`;
  };

  return (
    <View style={styles.container}>
      <Text style={styles.titulo}>Meus Pedidos</Text>
      <FlatList
        data={pedidos}
        keyExtractor={(item, index) => index.toString()}
        renderItem={({ item }) => (
          <View style={styles.pedido}>
            <Text style={styles.descricao}>{item.nome} (Qtd: {item.quantidade})</Text>
            <Text style={styles.preco}>R$ {(item.preco * item.quantidade).toFixed(2)}</Text>
            <Text style={styles.estimativa}>Estimativa de entrega: {gerarEstimativa()}</Text>
          </View>
        )}
        ListEmptyComponent={
          <Text style={styles.emptyMessage}>Nenhum pedido encontrado.</Text>
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 16, backgroundColor: '#fff' },
  titulo: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: 'center',
    color: '#FF011B',
  },
  pedido: {
    padding: 16,
    marginBottom: 10,
    backgroundColor: '#f0f0f0',
    borderRadius: 8,
    borderLeftWidth: 5,
    borderLeftColor: '#FF011B',
  },
  descricao: { fontSize: 18, color: '#333', marginBottom: 8 },
  preco: { fontSize: 16, fontWeight: 'bold', color: '#333' },
  estimativa: { fontSize: 14, color: '#555', marginTop: 4 },
  emptyMessage: { textAlign: 'center', fontSize: 16, color: '#999', marginTop: 20 },
});
