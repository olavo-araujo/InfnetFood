import { useState, useEffect } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, ScrollView, KeyboardAvoidingView, Platform, Alert } from 'react-native';
import * as Notifications from 'expo-notifications';

export default function Checkout({ route, navigation }) {
  const { carrinho, total } = route.params;

  const [selectedPayment, setSelectedPayment] = useState(null);
  const [endereco, setEndereco] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);

  useEffect(() => {
    Notifications.setNotificationHandler({
      handleNotification: async () => ({
        shouldShowAlert: true,
        shouldPlaySound: false,
        shouldSetBadge: false,
      }),
    });
  }, []);

  const handlePaymentSelect = (paymentMethod) => {
    setSelectedPayment(paymentMethod);
  };

  const handleOrderConfirmation = async () => {
    if (!endereco) {
      Alert.alert('Atenção', 'Por favor, insira o endereço para entrega.');
      return;
    }
    if (!selectedPayment) {
      Alert.alert('Atenção', 'Selecione um método de pagamento.');
      return;
    }
    setIsProcessing(true);

    await Notifications.scheduleNotificationAsync({
      content: {
        title: 'Pedido Confirmado!',
        body: 'Seu pedido está em preparação.',
      },
      trigger: null,
    });

    setTimeout(() => {
      setIsProcessing(false);
      navigation.navigate('Orders', { pedidos: carrinho });
    }, 2000);
  };

  return (
    <KeyboardAvoidingView
      style={{ flex: 1 }}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
    >
      <ScrollView
        contentContainerStyle={styles.scrollContainer}
        showsVerticalScrollIndicator={true}
        keyboardShouldPersistTaps="handled"
      >
        <Text style={styles.title}>Finalização de Compra</Text>
        <View style={styles.infoSection}>
          <Text style={styles.infoText}>Insira os dados de pagamento e endereço para concluir o pedido.</Text>
        </View>
        <View style={styles.inputSection}>
          <Text style={styles.inputLabel}>Endereço</Text>
          <TextInput
            style={styles.input}
            placeholder="Digite seu endereço completo"
            placeholderTextColor="#888"
            value={endereco}
            onChangeText={setEndereco}
          />
        </View>
        <View style={styles.paymentSection}>
          <Text style={styles.inputLabel}>Método de Pagamento</Text>
          <View style={styles.paymentOptions}>
            {['Dinheiro', 'PIX', 'Crédito', 'Débito'].map((method) => (
              <TouchableOpacity
                key={method}
                style={[styles.paymentButton, selectedPayment === method && styles.selectedPaymentButton]}
                onPress={() => handlePaymentSelect(method)}
              >
                <Text
                  style={[styles.paymentButtonText, selectedPayment === method && styles.selectedPaymentButtonText]}
                >
                  {method}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>
        <View style={styles.itemsList}>
          <Text style={styles.detailsText}>Itens no Carrinho:</Text>
          {carrinho.map((item) => (
            <View key={item.id} style={styles.item}>
              <Text style={styles.itemName}>{item.nome}</Text>
              <Text style={styles.itemQuantidade}>Qtd: {item.quantidade}</Text>
              <Text style={styles.itemPreco}>R${item.preco * item.quantidade}</Text>
            </View>
          ))}
        </View>
        <View style={styles.checkoutDetails}>
          <Text style={styles.detailsText}>Total: R${total}</Text>
          <TouchableOpacity
            style={[styles.finalizeButton, isProcessing && styles.processingButton]}
            onPress={handleOrderConfirmation}
            disabled={isProcessing}
          >
            <Text style={styles.finalizeButtonText}>
              {isProcessing ? 'Processando...' : 'PEDIR AGORA!'}
            </Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  scrollContainer: {
    flexGrow: 1,
    padding: 16,
  },
  title: {
    fontSize: 22,
    fontWeight: 'bold',
    textAlign: 'center',
    marginTop: 40,
    marginBottom: 16,
  },
  infoSection: {
    backgroundColor: '#F5F5F5',
    padding: 20,
    borderRadius: 10,
    marginBottom: 30,
  },
  infoText: {
    fontSize: 16,
    color: '#333',
    textAlign: 'center',
  },
  inputSection: {
    marginBottom: 20,
  },
  inputLabel: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 8,
  },
  input: {
    backgroundColor: '#F5F5F5',
    padding: 12,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#E0E0E0',
    fontSize: 16,
    color: '#333',
  },
  paymentSection: {
    marginBottom: 30,
  },
  paymentOptions: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 10,
  },
  paymentButton: {
    backgroundColor: '#FF011B',
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderRadius: 8,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#FF011B',
  },
  selectedPaymentButton: {
    backgroundColor: '#fff',
    borderColor: '#FF011B',
    borderWidth: 4,
  },
  paymentButtonText: {
    fontSize: 16,
    color: '#fff',
    fontWeight: 'bold',
  },
  selectedPaymentButtonText: {
    color: '#333',
  },
  itemsList: {
    marginBottom: 20,
  },
  item: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    padding: 16,
    backgroundColor: '#FF011B',
    borderRadius: 8,
    marginBottom: 10,
  },
  itemName: {
    fontSize: 18,
    color: '#fff',
  },
  itemQuantidade: {
    fontSize: 16,
    color: '#fff',
  },
  itemPreco: {
    fontSize: 16,
    color: '#fff',
  },
  checkoutDetails: {
    backgroundColor: '#F5F5F5',
    padding: 20,
    borderRadius: 10,
    alignItems: 'center',
    marginTop: 20,
  },
  detailsText: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 20,
  },
  finalizeButton: {
    backgroundColor: '#FF011B',
    paddingVertical: 12,
    borderRadius: 8,
    alignItems: 'center',
    width: '100%',
  },
  finalizeButtonText: {
    fontSize: 18,
    color: '#fff',
    fontWeight: 'bold',
  },
  processingButton: {
    backgroundColor: '#999',
  },
});
